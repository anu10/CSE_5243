input_data_dir = "data/input" #This is where all the input sgm files are stored
output_data_dir = "data/output" #Extracted features will be stored here
