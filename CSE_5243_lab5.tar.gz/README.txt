Instructions to run the code:
make

Alternatively, simply executing 'python cba_classifier.py'
on the terminal will execute the code.

Compatible with Python 2.6 only
